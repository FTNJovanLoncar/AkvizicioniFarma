﻿using Common;
using System;
using System.Windows.Threading;

namespace dCom.ViewModel
{
    internal class DigitalOutput : DigitalBase
	{
        private DispatcherTimer timer;
        public DigitalOutput(IConfigItem c, IProcessingManager processingManager, IStateUpdater stateUpdater, IConfiguration configuration, int i)
			: base(c, processingManager, stateUpdater, configuration, i)
		{
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(2); 
            timer.Tick += Timer_Tick; 
            timer.Start();
        }

		protected override bool WriteCommand_CanExecute(object obj)
		{
			return !(CommandedValue < 0 || CommandedValue > 1);
		}

        private void Timer_Tick(object sender, EventArgs e)
        {          
            WriteCommand_Execute(null);
        }

        protected override void WriteCommand_Execute(object obj)
        {
            try
            {
                this.processingManager.ExecuteWriteCommand(ConfigItem, configuration.GetTransactionId(), configuration.UnitAddress, address, (int)CommandedValue);
            }
            catch (Exception ex)
            {
                string message = $"{ex.TargetSite.ReflectedType.Name}.{ex.TargetSite.Name}: {ex.Message}";
                this.stateUpdater.LogMessage(message);
            }
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (timer != null)
                {
                    timer.Stop();
                    timer.Tick -= Timer_Tick;
                    timer = null;
                }
            }

        }
        public new void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}