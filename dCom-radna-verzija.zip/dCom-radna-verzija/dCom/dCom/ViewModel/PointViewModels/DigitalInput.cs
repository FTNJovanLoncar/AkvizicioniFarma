﻿using Common;
using System.Windows.Threading;
using System;

namespace dCom.ViewModel
{
    internal class DigitalInput : DigitalBase
	{
        private DispatcherTimer timer;
        public DigitalInput(IConfigItem c, IProcessingManager processingManager, IStateUpdater stateUpdater, IConfiguration configuration, int i) 
			: base(c, processingManager, stateUpdater, configuration, i)
		{
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(2); // Set the interval to 2 seconds
            timer.Tick += Timer_Tick; // Attach the event handler
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {           
            WriteCommand_Execute(null);
        }

        protected override void WriteCommand_Execute(object obj)
        {
            // Write command is not applicable for input points.
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (timer != null)
                {
                    timer.Stop();
                    timer.Tick -= Timer_Tick;
                    timer = null;
                }
            }

        }
        public new void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}