﻿using Common;
using System.Windows.Threading;
using System;

namespace dCom.ViewModel
{
    internal class AnalaogInput : AnalogBase
	{
        private DispatcherTimer timer;
        public AnalaogInput(IConfigItem c, IProcessingManager processingManager, IStateUpdater stateUpdater, IConfiguration configuration, int i)
			: base(c, processingManager, stateUpdater, configuration, i)
		{
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(4); 
            timer.Tick += Timer_Tick; 
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            
            WriteCommand_Execute(null);
        }

        protected override void WriteCommand_Execute(object obj)
        {
            // Write command is not applicable for input points.
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (timer != null)
                {
                    timer.Stop();
                    timer.Tick -= Timer_Tick;
                    timer = null;
                }
            }
           
        }

        public new void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}