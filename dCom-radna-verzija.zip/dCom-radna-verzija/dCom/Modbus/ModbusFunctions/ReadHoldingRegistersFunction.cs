﻿using Common;
using Modbus.FunctionParameters;
using System;
using System.Collections.Generic;
using System.Net;
using System.Reflection;

namespace Modbus.ModbusFunctions
{
    /// <summary>
    /// Class containing logic for parsing and packing modbus read holding registers functions/requests.
    /// </summary>
    public class ReadHoldingRegistersFunction : ModbusFunction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReadHoldingRegistersFunction"/> class.
        /// </summary>
        /// <param name="commandParameters">The modbus command parameters.</param>
        /// 
        private readonly PointType pointType;
        public ReadHoldingRegistersFunction(ModbusCommandParameters commandParameters) : base(commandParameters)
        {
            CheckArguments(MethodBase.GetCurrentMethod(), typeof(ModbusReadCommandParameters));
        }

        /// <inheritdoc />
        public override byte[] PackRequest()
        {
            ushort startingAddress = ((ModbusReadCommandParameters)CommandParameters).StartAddress;
            ushort quantity = ((ModbusReadCommandParameters)CommandParameters).Quantity;

            byte functionCode = 0x10;
           
            List<byte> packet = new List<byte>();
           
            packet.AddRange(BitConverter.GetBytes((ushort)0x1234));
           
            packet.AddRange(BitConverter.GetBytes((ushort)0x0000));
            
            packet.AddRange(BitConverter.GetBytes((ushort)0x0006));
           
            packet.Add(0xFF);
           
            packet.Add(functionCode);
            
            packet.AddRange(BitConverter.GetBytes(startingAddress));
           
            packet.AddRange(BitConverter.GetBytes(quantity));
            
            byte byteCount = (byte)(quantity * 2);

            packet.Add(byteCount);
            
            for (int i = 0; i < quantity; i++)
            {                
                packet.Add(0x00);
               
                packet.Add(0x00);
            }
           
            return packet.ToArray();
        }

        /// <inheritdoc />
        public override Dictionary<Tuple<PointType, ushort>, ushort> ParseResponse(byte[] response)
        {
            Dictionary<Tuple<PointType, ushort>, ushort> parsedData = new Dictionary<Tuple<PointType, ushort>, ushort>();
            
            if (response == null || response.Length < 3)
            {
                throw new ArgumentException("Invalid response.");
            }

            ushort startingAddress = ((ModbusReadCommandParameters)CommandParameters).StartAddress;
            ushort quantity = ((ModbusReadCommandParameters)CommandParameters).Quantity;

            int expectedResponseLength = 2 + 2 + 1 + (quantity * 2);

            if (response.Length != expectedResponseLength)
            {
                throw new ArgumentException("Invalid response length.");
            }

            int dataIndex = 3;

            for (int i = 0; i < quantity; i++)
            {
                byte highByte = response[dataIndex + i * 2];
                byte lowByte = response[dataIndex + i * 2 + 1];

                ushort dataValue = (ushort)((highByte << 8) | lowByte);

                ushort address = (ushort)(startingAddress + i);

                Tuple<PointType, ushort> point = new Tuple<PointType, ushort>(pointType, address);

                parsedData.Add(point, dataValue);
            }

            return parsedData;
        }
    
    }
}