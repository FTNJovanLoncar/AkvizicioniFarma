﻿using Common;
using Modbus.FunctionParameters;
using System;
using System.Collections.Generic;
using System.Net;
using System.Reflection;

namespace Modbus.ModbusFunctions
{
    /// <summary>
    /// Class containing logic for parsing and packing modbus write coil functions/requests.
    /// </summary>
    public class WriteSingleCoilFunction : ModbusFunction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WriteSingleCoilFunction"/> class.
        /// </summary>
        /// <param name="commandParameters">The modbus command parameters.</param>
        public WriteSingleCoilFunction(ModbusCommandParameters commandParameters) : base(commandParameters)
        {
            CheckArguments(MethodBase.GetCurrentMethod(), typeof(ModbusWriteCommandParameters));
        }

        /// <inheritdoc />
        public override byte[] PackRequest()
        {
            ushort coilAddress = ((ModbusWriteCommandParameters)CommandParameters).OutputAddress;
            bool coilValue = ((ModbusWriteCommandParameters)CommandParameters).Value != 0;
            
            byte functionCode = 0x05;

            byte[] packet = new byte[6];

            packet[0] = 0x00;
            packet[1] = 0x01;

            packet[2] = 0x00;
            packet[3] = 0x00;

            packet[4] = 0x00;
            packet[5] = 0x06;

            packet[6] = 0xFF;

            packet[7] = functionCode;

            packet[8] = (byte)(coilAddress >> 8);
            packet[9] = (byte)coilAddress;

            packet[10] = coilValue ? (byte)0xFF : (byte)0x00;
            packet[11] = 0x00;

            return packet;
        }

        /// <inheritdoc />
        public override Dictionary<Tuple<PointType, ushort>, ushort> ParseResponse(byte[] response)
        {
            Dictionary<Tuple<PointType, ushort>, ushort> parsedData = new Dictionary<Tuple<PointType, ushort>, ushort>();

            if (response == null || response.Length != 12)
            {
                throw new ArgumentException("Invalid response.");
            }

            ushort coilAddress = (ushort)((response[8] << 8) | response[9]);
            ushort coilValue = (ushort)((response[10] << 8) | response[11]);

            Tuple<PointType, ushort> point = new Tuple<PointType, ushort>(PointType.DIGITAL_OUTPUT, coilAddress);

            parsedData.Add(point, coilValue);

            return parsedData;
        }
    }
}